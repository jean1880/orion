(function () {
  'use strict';

  angular.module('dogToolApp')
    .constant('EVENT_COLOURS', {
      event: '#01997b',
      booking: '#3a87ad'
    });
}())